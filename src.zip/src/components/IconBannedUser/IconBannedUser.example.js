import IconBannedUser from './IconBannedUser';

export const Icon = {
  component: IconBannedUser,
  props: {},
  group: 'icons',
};
