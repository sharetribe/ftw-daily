import IconEmailSent from './IconEmailSent';

export const Icon = {
  component: IconEmailSent,
  props: {},
  group: 'icons',
};
