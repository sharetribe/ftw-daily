import IconSocialMediaFacebook from './IconSocialMediaFacebook';

export const Icon = {
  component: IconSocialMediaFacebook,
  props: {},
  group: 'icons',
};
