import IconReviewUser from './IconReviewUser';

export const Icon = {
  component: IconReviewUser,
  props: {},
  group: 'icons',
};
