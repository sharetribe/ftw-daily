import Footer from './Footer';
import css from './FooterExample.module.css';

export const Default = {
  component: Footer,
  props: { className: css.example },
};
