import IconSuccess from './IconSuccess';

export const Icon = {
  component: IconSuccess,
  props: {},
  group: 'icons',
};
