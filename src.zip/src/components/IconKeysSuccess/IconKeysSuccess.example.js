import IconKeysSuccess from './IconKeysSuccess';

export const Icon = {
  component: IconKeysSuccess,
  props: {},
  group: 'icons',
};
